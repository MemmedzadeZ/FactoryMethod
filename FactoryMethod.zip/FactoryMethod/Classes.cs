﻿using System;

namespace FactoryMethod
{
    public interface Button
    {
        void Render();
        void OnClick();
    }

    public class WindowsButton : Button
    {
        public void OnClick()
        {
            Console.WriteLine("Windows Button Clicked");
        }

        public void Render()
        {
            Console.WriteLine("Rendering Windows Button");
        }
    }

    public class HTMLButton : Button
    {
        public void OnClick()
        {
            Console.WriteLine("HTML Button Clicked");
        }

        public void Render()
        {
            Console.WriteLine("Rendering HTML Button");
        }
    }

    public abstract class Dialog
    {
        public void RenderDialog()
        {
            Button button = CreateButton();
            button.Render();
            button.OnClick();
        }

        protected abstract Button CreateButton();
    }

    public class WindowsDialog : Dialog
    {
        protected override Button CreateButton()
        {
            return new WindowsButton();
        }
    }

    public class WebDialog : Dialog
    {
        protected override Button CreateButton()
        {
            return new HTMLButton();
        }
    }

    class Program
    {
        static void Main()
        {
            Dialog windowsDialog = new WindowsDialog();
            windowsDialog.RenderDialog();

            Dialog webDialog = new WebDialog();
            webDialog.RenderDialog();
        }
    }
}
