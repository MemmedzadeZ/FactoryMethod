﻿using FactoryMethod;

class Program
{
    static void Main()
    {
        Dialog windowsDialog = new WindowsDialog();
        windowsDialog.RenderDialog();

        Dialog webDialog = new WebDialog();
        webDialog.RenderDialog();
    }
}